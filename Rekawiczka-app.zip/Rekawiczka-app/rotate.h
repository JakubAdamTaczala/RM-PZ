//#ifndef ROTATE_H
//#define ROTATE_H

//#include <QLabel>

//class rotate : public QLabel
//{
//    Q_OBJECT

//public:
//    explicit rotate(QWidget *parent=0);
//    explicit rotate(const QString &text, QWidget *parent=0);

//protected:
//    void paintEvent(QPaintEvent*);
//    QSize sizeHint() const ;
//    QSize minimumSizeHint() const;
//};

//#endif // ROTATE_H
